-- ============================================================
-- PASSO 2: CONFIGURAR MASTER
-- Execute este bloco DEPOIS do step1_fix_trigger.sql
-- ============================================================

-- 1. Adicionar MASTER ao enum role
DO $$ 
BEGIN 
    IF NOT EXISTS (
        SELECT 1 FROM pg_type t 
        JOIN pg_enum e ON t.oid = e.enumtypid 
        WHERE t.typname = 'role' AND e.enumlabel = 'MASTER'
    ) THEN
        ALTER TYPE role ADD VALUE 'MASTER';
        RAISE NOTICE '✅ Valor MASTER adicionado ao enum role';
    ELSE
        RAISE NOTICE '⚠️ Valor MASTER já existe no enum role';
    END IF;
END $$;

-- 2. Criar clínica MASTER
INSERT INTO public.clinics (id, name, cnpj, code, status)
VALUES (
    '00000000-0000-0000-0000-000000000000', 
    'CLINICPRO GESTÃO GLOBAL', 
    '00.000.000/0001-00',
    'MASTER', 
    'ACTIVE'
)
ON CONFLICT (id) DO UPDATE SET
    name = EXCLUDED.name,
    code = EXCLUDED.code,
    status = EXCLUDED.status;

-- 3. Elevar usuário master@clinicpro.com para MASTER
UPDATE public.users 
SET 
    role = 'MASTER', 
    clinic_id = '00000000-0000-0000-0000-000000000000'
WHERE email = 'master@clinicpro.com';

-- 4. Verificar se funcionou
SELECT 
    '=== CLÍNICA MASTER ===' as info,
    id, name, code, status
FROM public.clinics
WHERE code = 'MASTER';

SELECT 
    '=== USUÁRIO MASTER ===' as info,
    u.id, u.email, u.name, u.role, 
    c.name as clinica, c.code
FROM public.users u
LEFT JOIN public.clinics c ON u.clinic_id = c.id
WHERE u.email = 'master@clinicpro.com';
