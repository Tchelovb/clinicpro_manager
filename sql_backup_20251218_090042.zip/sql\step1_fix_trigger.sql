-- ============================================================
-- PASSO 1: PREPARAR A TABELA CLINICS
-- Execute este bloco PRIMEIRO
-- ============================================================

-- Remover TODOS os triggers da tabela clinics temporariamente
DROP TRIGGER IF EXISTS update_clinics_updated_at ON public.clinics;
DROP TRIGGER IF EXISTS set_updated_at ON public.clinics;

-- Adicionar a coluna updated_at se não existir
DO $$ 
BEGIN 
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'clinics' 
        AND column_name = 'updated_at'
    ) THEN
        ALTER TABLE public.clinics 
        ADD COLUMN updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();
        RAISE NOTICE '✅ Coluna updated_at adicionada';
    ELSE
        RAISE NOTICE '⚠️ Coluna updated_at já existe';
    END IF;
END $$;

-- Recriar o trigger corretamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_clinics_updated_at
    BEFORE UPDATE ON public.clinics
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Verificar se o trigger foi criado
SELECT 
    '✅ Trigger recriado com sucesso' as status,
    trigger_name, 
    event_manipulation, 
    event_object_table
FROM information_schema.triggers
WHERE trigger_name = 'update_clinics_updated_at';
