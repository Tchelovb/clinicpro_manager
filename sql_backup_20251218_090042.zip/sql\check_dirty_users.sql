﻿SELECT id, name, role, professional_id FROM public.users WHERE role IN ('RECEPTIONIST', 'ASSISTANT') AND professional_id IS NOT NULL;
