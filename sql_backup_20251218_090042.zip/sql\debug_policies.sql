-- ============================================================
-- DIAGNÓSTICO DE POLÍTICAS E DADOS
-- ============================================================

SELECT 
    schemaname,
    tablename,
    policyname,
    cmd,
    qual,
    with_check
FROM pg_policies
WHERE tablename = 'users';

SELECT '=== DADOS DA LOOKUP ===' as info;
SELECT count(*) FROM public.user_roles_lookup;

SELECT '=== DADOS DO MASTER NA LOOKUP ===' as info;
SELECT * FROM public.user_roles_lookup WHERE role = 'MASTER';
