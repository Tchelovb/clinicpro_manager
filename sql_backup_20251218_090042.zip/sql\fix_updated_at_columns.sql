-- FIX: MISSING updated_at SCALAR
-- Description: Adds 'updated_at' column to tables that might have triggers expecting it.

-- 1. Ensure Trigger Function Exists
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- 2. Fix USERS table
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();

DROP TRIGGER IF EXISTS update_users_modtime ON public.users;
CREATE TRIGGER update_users_modtime 
BEFORE UPDATE ON public.users 
FOR EACH ROW EXECUTE PROCEDURE public.update_updated_at_column();

-- 3. Fix PROFESSIONALS table
ALTER TABLE public.professionals ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();

DROP TRIGGER IF EXISTS update_professionals_modtime ON public.professionals;
CREATE TRIGGER update_professionals_modtime 
BEFORE UPDATE ON public.professionals 
FOR EACH ROW EXECUTE PROCEDURE public.update_updated_at_column();

-- 4. Fix CLINICS table
ALTER TABLE public.clinics ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();

DROP TRIGGER IF EXISTS update_clinics_modtime ON public.clinics;
CREATE TRIGGER update_clinics_modtime 
BEFORE UPDATE ON public.clinics 
FOR EACH ROW EXECUTE PROCEDURE public.update_updated_at_column();

-- 5. Fix USER_ROLES_LOOKUP (if exists)
DO $$
BEGIN
    IF EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'user_roles_lookup') THEN
        ALTER TABLE public.user_roles_lookup ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();
        
        DROP TRIGGER IF EXISTS update_user_roles_lookup_modtime ON public.user_roles_lookup;
        CREATE TRIGGER update_user_roles_lookup_modtime 
        BEFORE UPDATE ON public.user_roles_lookup 
        FOR EACH ROW EXECUTE PROCEDURE public.update_updated_at_column();
    END IF;
END $$;
