-- ============================================================
-- FIX DEFINITIVO: RECURSÃO RLS - DESABILITAR RLS NAS FUNÇÕES
-- ============================================================

-- 1. Recriar função get_user_role SEM RLS
CREATE OR REPLACE FUNCTION public.get_user_role(user_id UUID)
RETURNS TEXT
SECURITY DEFINER
SET search_path = public
LANGUAGE sql
STABLE
AS $$
    -- Consulta direta sem disparar RLS
    SELECT role::text FROM public.users WHERE id = user_id LIMIT 1;
$$;

-- 2. Recriar função get_user_clinic_id SEM RLS  
CREATE OR REPLACE FUNCTION public.get_user_clinic_id(user_id UUID)
RETURNS UUID
SECURITY DEFINER
SET search_path = public
LANGUAGE sql
STABLE
AS $$
    -- Consulta direta sem disparar RLS
    SELECT clinic_id FROM public.users WHERE id = user_id LIMIT 1;
$$;

-- 3. DESABILITAR RLS temporariamente na tabela users
ALTER TABLE public.users DISABLE ROW LEVEL SECURITY;

-- 4. Testar as funções
SELECT 
    '=== TESTE DAS FUNÇÕES ===' as info,
    public.get_user_role(auth.uid()) as minha_role,
    public.get_user_clinic_id(auth.uid()) as minha_clinica;

-- 5. REABILITAR RLS na tabela users
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- 6. Recriar política da tabela USERS usando as funções
DROP POLICY IF EXISTS "clinic_isolation" ON public.users;
CREATE POLICY "clinic_isolation" ON public.users 
FOR ALL USING (
    public.get_user_role(auth.uid()) = 'MASTER'
    OR
    clinic_id = public.get_user_clinic_id(auth.uid())
);

-- 7. Atualizar todas as outras políticas
DROP POLICY IF EXISTS "clinic_isolation" ON public.clinics;
CREATE POLICY "clinic_isolation" ON public.clinics 
FOR ALL USING (
    public.get_user_role(auth.uid()) = 'MASTER'
    OR
    id = public.get_user_clinic_id(auth.uid())
);

DROP POLICY IF EXISTS "clinic_isolation" ON public.patients;
CREATE POLICY "clinic_isolation" ON public.patients 
FOR ALL USING (
    public.get_user_role(auth.uid()) = 'MASTER'
    OR
    clinic_id = public.get_user_clinic_id(auth.uid())
);

DROP POLICY IF EXISTS "clinic_isolation" ON public.procedure;
CREATE POLICY "clinic_isolation" ON public.procedure 
FOR ALL USING (
    public.get_user_role(auth.uid()) = 'MASTER'
    OR
    clinic_id = public.get_user_clinic_id(auth.uid())
);

DROP POLICY IF EXISTS "clinic_isolation" ON public.appointments;
CREATE POLICY "clinic_isolation" ON public.appointments 
FOR ALL USING (
    public.get_user_role(auth.uid()) = 'MASTER'
    OR
    clinic_id = public.get_user_clinic_id(auth.uid())
);

DROP POLICY IF EXISTS "clinic_isolation" ON public.leads;
CREATE POLICY "clinic_isolation" ON public.leads 
FOR ALL USING (
    public.get_user_role(auth.uid()) = 'MASTER'
    OR
    clinic_id = public.get_user_clinic_id(auth.uid())
);

DROP POLICY IF EXISTS "clinic_isolation" ON public.budgets;
CREATE POLICY "clinic_isolation" ON public.budgets 
FOR ALL USING (
    public.get_user_role(auth.uid()) = 'MASTER'
    OR
    patient_id IN (
        SELECT id FROM public.patients 
        WHERE clinic_id = public.get_user_clinic_id(auth.uid())
    )
);

DROP POLICY IF EXISTS "clinic_isolation" ON public.financial_installments;
CREATE POLICY "clinic_isolation" ON public.financial_installments 
FOR ALL USING (
    public.get_user_role(auth.uid()) = 'MASTER'
    OR
    clinic_id = public.get_user_clinic_id(auth.uid())
);

DROP POLICY IF EXISTS "clinic_isolation" ON public.expenses;
CREATE POLICY "clinic_isolation" ON public.expenses 
FOR ALL USING (
    public.get_user_role(auth.uid()) = 'MASTER'
    OR
    clinic_id = public.get_user_clinic_id(auth.uid())
);

DROP POLICY IF EXISTS "clinic_isolation" ON public.transactions;
CREATE POLICY "clinic_isolation" ON public.transactions 
FOR ALL USING (
    public.get_user_role(auth.uid()) = 'MASTER'
    OR
    clinic_id = public.get_user_clinic_id(auth.uid())
);

DROP POLICY IF EXISTS "clinic_isolation" ON public.professionals;
CREATE POLICY "clinic_isolation" ON public.professionals 
FOR ALL USING (
    public.get_user_role(auth.uid()) = 'MASTER'
    OR
    clinic_id = public.get_user_clinic_id(auth.uid())
);

DROP POLICY IF EXISTS "clinic_isolation" ON public.price_tables;
CREATE POLICY "clinic_isolation" ON public.price_tables 
FOR ALL USING (
    public.get_user_role(auth.uid()) = 'MASTER'
    OR
    clinic_id = public.get_user_clinic_id(auth.uid())
);

DROP POLICY IF EXISTS "clinic_isolation" ON public.conventions;
CREATE POLICY "clinic_isolation" ON public.conventions 
FOR ALL USING (
    public.get_user_role(auth.uid()) = 'MASTER'
    OR
    clinic_id = public.get_user_clinic_id(auth.uid())
);

DROP POLICY IF EXISTS "clinic_isolation" ON public.cash_registers;
CREATE POLICY "clinic_isolation" ON public.cash_registers 
FOR ALL USING (
    public.get_user_role(auth.uid()) = 'MASTER'
    OR
    clinic_id = public.get_user_clinic_id(auth.uid())
);

SELECT '✅ RLS CORRIGIDO - FUNÇÕES SQL ESTÁVEIS' as status;
