-- ============================================================
-- MASTER SETUP SCRIPT
-- Configuração completa do sistema MASTER para ClinicPro SaaS
-- ============================================================

-- 1. Adicionar o valor 'MASTER' ao tipo enum de roles
-- Nota: O PostgreSQL não permite IF NOT EXISTS em ADD VALUE, 
-- por isso executamos este bloco para garantir a inclusão.
DO $$ 
BEGIN 
    IF NOT EXISTS (
        SELECT 1 FROM pg_type t 
        JOIN pg_enum e ON t.oid = e.enumtypid 
        WHERE t.typname = 'role' AND e.enumlabel = 'MASTER'
    ) THEN
        ALTER TYPE role ADD VALUE 'MASTER';
        RAISE NOTICE '✅ Valor MASTER adicionado ao enum role';
    ELSE
        RAISE NOTICE '⚠️ Valor MASTER já existe no enum role';
    END IF;
END $$;

-- 2. Adicionar coluna 'status' à tabela clinics (se não existir)
DO $$ 
BEGIN 
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'clinics' 
        AND column_name = 'status'
    ) THEN
        ALTER TABLE public.clinics 
        ADD COLUMN status TEXT NOT NULL DEFAULT 'ACTIVE';
        
        RAISE NOTICE '✅ Coluna status adicionada à tabela clinics';
    ELSE
        RAISE NOTICE '⚠️ Coluna status já existe na tabela clinics';
    END IF;
END $$;

-- 3. Criar a "Clínica Zero" (A clínica que gerencia o sistema)
-- UUID fixo e fácil de identificar para a clínica master
INSERT INTO public.clinics (id, name, cnpj, code, status, created_at)
VALUES (
    '00000000-0000-0000-0000-000000000000', 
    'CLINICPRO GESTÃO GLOBAL', 
    '00.000.000/0001-00', 
    'MASTER', 
    'ACTIVE',
    NOW()
)
ON CONFLICT (id) DO UPDATE SET
    name = EXCLUDED.name,
    code = EXCLUDED.code,
    status = EXCLUDED.status;

-- Verificar se a clínica MASTER foi criada
DO $$
DECLARE
    clinic_exists BOOLEAN;
BEGIN
    SELECT EXISTS(
        SELECT 1 FROM public.clinics 
        WHERE id = '00000000-0000-0000-0000-000000000000'
    ) INTO clinic_exists;
    
    IF clinic_exists THEN
        RAISE NOTICE '✅ Clínica MASTER criada/atualizada com sucesso';
    ELSE
        RAISE WARNING '❌ Falha ao criar clínica MASTER';
    END IF;
END $$;

-- ============================================================
-- INSTRUÇÕES PARA ELEVAR UM USUÁRIO A MASTER
-- ============================================================

-- 4. Transformar o seu usuário em MASTER e vinculá-lo à Clínica Zero
-- ⚠️ IMPORTANTE: SUBSTITUA 'seu-email@exemplo.com' pelo email que você usa para entrar no sistema

/*
UPDATE public.users 
SET 
    role = 'MASTER', 
    clinic_id = '00000000-0000-0000-0000-000000000000'
WHERE email = 'seu-email@exemplo.com';
*/

-- ============================================================
-- VERIFICAÇÃO FINAL
-- ============================================================

-- 5. Verificar se tudo está configurado corretamente
SELECT 
    '=== VERIFICAÇÃO DO SETUP MASTER ===' as info;

-- Verificar enum role
SELECT 
    'Valores do enum role:' as info,
    enumlabel as role_value
FROM pg_type t 
JOIN pg_enum e ON t.oid = e.enumtypid 
WHERE t.typname = 'role'
ORDER BY e.enumsortorder;

-- Verificar clínica MASTER
SELECT 
    '=== CLÍNICA MASTER ===' as info,
    id, name, code, status, created_at
FROM public.clinics
WHERE code = 'MASTER';

-- Verificar usuários MASTER (se houver)
SELECT 
    '=== USUÁRIOS MASTER ===' as info,
    u.id, u.email, u.name, u.role, c.name as clinica_nome, c.code as clinica_codigo
FROM public.users u
LEFT JOIN public.clinics c ON u.clinic_id = c.id
WHERE u.role = 'MASTER';

-- ============================================================
-- PRÓXIMOS PASSOS
-- ============================================================

/*
1. Execute este script no SQL Editor do Supabase
2. Descomente e execute o comando UPDATE acima com seu email
3. Execute o script master_rls_policies.sql para atualizar as políticas de segurança
4. Faça login com:
   - Código da Clínica: MASTER
   - Email: (seu email)
   - Senha: (sua senha)
5. Você será redirecionado para /master com acesso total ao sistema
*/
