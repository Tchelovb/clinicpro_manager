-- =================================================================
-- REFACTOR: PROFESSIONAL ENTITY & USER LINK
-- Description: Enforces strict linking rules between Users and Professionals.
-- =================================================================

-- 1. CLEANUP INVALID DATA
-- Remove professional_id from users who should not have it (Receptionists, Assistants)
UPDATE public.users 
SET professional_id = NULL 
WHERE role IN ('RECEPTIONIST', 'ASSISTANT');

-- 2. MIGRATE PROFESSIONAL SCHEDULES
-- Current State: professional_schedules.professional_id -> users.id
-- Target State: professional_schedules.professional_id -> professionals.id

-- A. Create temporary column
ALTER TABLE public.professional_schedules ADD COLUMN IF NOT EXISTS new_prof_id UUID;

-- B. Fill new column mapping via users table
-- users table has professional_id which points to professionals.id
-- But wait, schedules currently point to users.id.
-- We want schedules to point to professionals.id.
-- IF a user is a DENTIST, they MUST have a professional_id (we will enforce this).
-- For existing DENTISTS, we need to ensure they have a professional record.

-- Create professionals for DENTISTS who don't have one (Migration Fix)
INSERT INTO public.professionals (clinic_id, name, is_active)
SELECT clinic_id, name, active
FROM public.users
WHERE role = 'DENTIST' AND professional_id IS NULL;

-- Link these new professionals back to users
UPDATE public.users u
SET professional_id = p.id
FROM public.professionals p
WHERE u.role = 'DENTIST' 
  AND u.professional_id IS NULL 
  AND u.name = p.name 
  AND u.clinic_id = p.clinic_id;

-- Now migrate the schedules
UPDATE public.professional_schedules ps
SET new_prof_id = u.professional_id
FROM public.users u
WHERE ps.professional_id = u.id;

-- Delete orphaned schedules (should not exist if integrity is good)
DELETE FROM public.professional_schedules WHERE new_prof_id IS NULL;

-- C. Drop old constraint and column, rename new
ALTER TABLE public.professional_schedules DROP CONSTRAINT IF EXISTS professional_schedules_professional_id_fkey;
ALTER TABLE public.professional_schedules DROP COLUMN professional_id;
ALTER TABLE public.professional_schedules RENAME COLUMN new_prof_id TO professional_id;

-- D. Add new Foreign Key
ALTER TABLE public.professional_schedules 
ADD CONSTRAINT professional_schedules_professional_id_fkey 
FOREIGN KEY (professional_id) REFERENCES public.professionals(id) ON DELETE CASCADE;

-- 3. APPLY CHECK CONSTRAINT ON USERS
ALTER TABLE public.users DROP CONSTRAINT IF EXISTS check_professional_role_link;
ALTER TABLE public.users ADD CONSTRAINT check_professional_role_link CHECK (
  (role = 'DENTIST' AND professional_id IS NOT NULL) OR
  (role = 'ADMIN') OR -- Admin can be NULL or NOT NULL
  (role IN ('RECEPTIONIST', 'ASSISTANT') AND professional_id IS NULL)
);

-- 4. CREATE TRANSACTIONAL RPC
CREATE OR REPLACE FUNCTION public.manage_user_professional(
    p_user_id UUID, -- If null, create user? (Requires auth handling, assume update for now or handle ID gen)
    p_clinic_id UUID,
    p_name TEXT,
    p_email TEXT,
    p_role role,
    p_color TEXT,
    p_active BOOLEAN,
    p_professional_data JSONB -- { council_number, specialty, etc. } or NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID;
    v_prof_id UUID;
    v_new_user BOOLEAN := false;
BEGIN
    -- Determine User ID
    IF p_user_id IS NULL THEN
        -- Generate new ID (Simulating Auth creation - In real app, this should match Auth.users)
        -- For this refactor, we assume public.users ID generation or passed from Auth
        v_user_id := uuid_generate_v4(); 
        v_new_user := true;
    ELSE
        v_user_id := p_user_id;
    END IF;

    -- Handle Professional Logic
    IF (p_role = 'DENTIST') OR (p_role = 'ADMIN' AND p_professional_data IS NOT NULL) THEN
        -- Upsert Professional
        -- Need to know if we are updating an existing professional linked to this user?
        SELECT professional_id INTO v_prof_id FROM public.users WHERE id = v_user_id;
        
        IF v_prof_id IS NOT NULL THEN
            UPDATE public.professionals
            SET 
                name = p_name, -- Keep name synced
                crc = p_professional_data->>'council_number',
                council = p_professional_data->>'council_type',
                specialty = p_professional_data->>'specialty',
                color = p_color,
                is_active = p_active
            WHERE id = v_prof_id;
        ELSE
            INSERT INTO public.professionals (
                clinic_id, name, crc, council, specialty, color, is_active
            ) VALUES (
                p_clinic_id,
                p_name,
                p_professional_data->>'council_number',
                p_professional_data->>'council_type',
                p_professional_data->>'specialty',
                p_color,
                p_active
            ) RETURNING id INTO v_prof_id;
        END IF;

    ELSE
        -- Role does not allow professional (or Admin turned it off)
        -- Should we delete existing professional? Or just unlink?
        -- Prompt says: RECEPTIONIST/ASSISTANT professional_id must be NULL.
        v_prof_id := NULL;
        -- Optional: Delete orphan professional if desired, or keep for history.
    END IF;

    -- Upsert User
    INSERT INTO public.users (
        id, clinic_id, email, name, role, color, active, professional_id
    ) VALUES (
        v_user_id, p_clinic_id, p_email, p_name, p_role, p_color, p_active, v_prof_id
    )
    ON CONFLICT (id) DO UPDATE SET
        name = EXCLUDED.name,
        email = EXCLUDED.email,
        role = EXCLUDED.role,
        color = EXCLUDED.color,
        active = EXCLUDED.active,
        professional_id = v_prof_id;

    RETURN jsonb_build_object('user_id', v_user_id, 'professional_id', v_prof_id);
END;
$$;
