-- ============================================================
-- MASTER RLS POLICIES
-- Atualização de políticas Row Level Security para permitir acesso MASTER
-- ============================================================

-- Este script atualiza todas as políticas RLS para permitir que usuários
-- com role = 'MASTER' tenham acesso completo a todos os dados do sistema,
-- enquanto mantém o isolamento de dados para usuários normais.

-- ============================================================
-- TABELA: clinics
-- ============================================================

DROP POLICY IF EXISTS "clinic_isolation" ON public.clinics;
CREATE POLICY "clinic_isolation" ON public.clinics 
FOR ALL USING (
    -- MASTER pode ver todas as clínicas
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    -- Usuários normais veem apenas sua própria clínica
    id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
);

-- ============================================================
-- TABELA: users
-- ============================================================

DROP POLICY IF EXISTS "clinic_isolation" ON public.users;
CREATE POLICY "clinic_isolation" ON public.users 
FOR ALL USING (
    -- MASTER pode ver todos os usuários
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    -- Usuários normais veem apenas usuários da mesma clínica
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
);

-- ============================================================
-- TABELA: patients
-- ============================================================

DROP POLICY IF EXISTS "clinic_isolation" ON public.patients;
CREATE POLICY "clinic_isolation" ON public.patients 
FOR ALL USING (
    -- MASTER pode ver todos os pacientes
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    -- Usuários normais veem apenas pacientes da mesma clínica
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
);

-- ============================================================
-- TABELA: procedure
-- ============================================================

DROP POLICY IF EXISTS "clinic_isolation" ON public.procedure;
CREATE POLICY "clinic_isolation" ON public.procedure 
FOR ALL USING (
    -- MASTER pode ver todos os procedimentos
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    -- Usuários normais veem apenas procedimentos da mesma clínica
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
);

-- ============================================================
-- TABELA: appointments
-- ============================================================

DROP POLICY IF EXISTS "clinic_isolation" ON public.appointments;
CREATE POLICY "clinic_isolation" ON public.appointments 
FOR ALL USING (
    -- MASTER pode ver todos os agendamentos
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    -- Usuários normais veem apenas agendamentos da mesma clínica
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
);

-- ============================================================
-- TABELA: leads
-- ============================================================

DROP POLICY IF EXISTS "clinic_isolation" ON public.leads;
CREATE POLICY "clinic_isolation" ON public.leads 
FOR ALL USING (
    -- MASTER pode ver todos os leads
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    -- Usuários normais veem apenas leads da mesma clínica
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
);

-- ============================================================
-- TABELA: budgets (via patient_id)
-- ============================================================

DROP POLICY IF EXISTS "clinic_isolation" ON public.budgets;
CREATE POLICY "clinic_isolation" ON public.budgets 
FOR ALL USING (
    -- MASTER pode ver todos os orçamentos
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    -- Usuários normais veem apenas orçamentos de pacientes da mesma clínica
    patient_id IN (
        SELECT id FROM public.patients 
        WHERE clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
    )
);

-- ============================================================
-- TABELA: financial_installments
-- ============================================================

DROP POLICY IF EXISTS "clinic_isolation" ON public.financial_installments;
CREATE POLICY "clinic_isolation" ON public.financial_installments 
FOR ALL USING (
    -- MASTER pode ver todas as parcelas
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    -- Usuários normais veem apenas parcelas da mesma clínica
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
);

-- ============================================================
-- TABELA: expenses
-- ============================================================

DROP POLICY IF EXISTS "clinic_isolation" ON public.expenses;
CREATE POLICY "clinic_isolation" ON public.expenses 
FOR ALL USING (
    -- MASTER pode ver todas as despesas
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    -- Usuários normais veem apenas despesas da mesma clínica
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
);

-- ============================================================
-- TABELA: transactions
-- ============================================================

DROP POLICY IF EXISTS "clinic_isolation" ON public.transactions;
CREATE POLICY "clinic_isolation" ON public.transactions 
FOR ALL USING (
    -- MASTER pode ver todas as transações
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    -- Usuários normais veem apenas transações da mesma clínica
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
);

-- ============================================================
-- TABELA: professionals
-- ============================================================

DROP POLICY IF EXISTS "clinic_isolation" ON public.professionals;
CREATE POLICY "clinic_isolation" ON public.professionals 
FOR ALL USING (
    -- MASTER pode ver todos os profissionais
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    -- Usuários normais veem apenas profissionais da mesma clínica
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
);

-- ============================================================
-- TABELA: price_tables
-- ============================================================

DROP POLICY IF EXISTS "clinic_isolation" ON public.price_tables;
CREATE POLICY "clinic_isolation" ON public.price_tables 
FOR ALL USING (
    -- MASTER pode ver todas as tabelas de preço
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    -- Usuários normais veem apenas tabelas de preço da mesma clínica
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
);

-- ============================================================
-- TABELA: conventions
-- ============================================================

DROP POLICY IF EXISTS "clinic_isolation" ON public.conventions;
CREATE POLICY "clinic_isolation" ON public.conventions 
FOR ALL USING (
    -- MASTER pode ver todos os convênios
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    -- Usuários normais veem apenas convênios da mesma clínica
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
);

-- ============================================================
-- TABELA: cash_registers
-- ============================================================

DROP POLICY IF EXISTS "clinic_isolation" ON public.cash_registers;
CREATE POLICY "clinic_isolation" ON public.cash_registers 
FOR ALL USING (
    -- MASTER pode ver todos os caixas
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    -- Usuários normais veem apenas caixas da mesma clínica
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
);

-- ============================================================
-- VERIFICAÇÃO
-- ============================================================

SELECT 
    '=== POLÍTICAS RLS ATUALIZADAS ===' as info;

-- Listar todas as políticas criadas
SELECT 
    schemaname,
    tablename,
    policyname,
    permissive,
    roles,
    cmd,
    qual
FROM pg_policies
WHERE schemaname = 'public'
AND policyname = 'clinic_isolation'
ORDER BY tablename;

-- ============================================================
-- NOTAS IMPORTANTES
-- ============================================================

/*
1. Estas políticas permitem que usuários MASTER vejam TODOS os dados
2. Usuários normais continuam vendo apenas dados da própria clínica
3. O isolamento é mantido através do clinic_id
4. Para tabelas relacionadas (como budgets), o filtro é feito via JOIN
5. Certifique-se de que o usuário MASTER está vinculado à clínica MASTER
*/
