-- ============================================================
-- MIGRATION: Unificar Conventions em Price Tables
-- ============================================================

-- 1. Ampliar a tabela price_tables com campos de convênio
ALTER TABLE public.price_tables 
ADD COLUMN IF NOT EXISTS type text DEFAULT 'PARTICULAR' CHECK (type IN ('PARTICULAR', 'CONVENIO', 'PARCERIA', 'OUTROS')),
ADD COLUMN IF NOT EXISTS external_code text, -- Antigo código do convênio
ADD COLUMN IF NOT EXISTS contact_phone text,
ADD COLUMN IF NOT EXISTS notes text;

-- 2. Criar um índice para busca rápida por tipo
CREATE INDEX IF NOT EXISTS idx_price_tables_type ON public.price_tables(type);

-- 3. Migrar dados da tabela conventions para a price_tables
-- Usa NOT EXISTS para evitar duplicatas, já que não temos constraint UNIQUE(clinic_id, name)
INSERT INTO public.price_tables (clinic_id, name, type, external_code, is_active)
SELECT 
    c.clinic_id, 
    c.name, 
    'CONVENIO', 
    c.code, 
    (c.status = 'Ativo')
FROM public.conventions c
WHERE NOT EXISTS (
    SELECT 1 FROM public.price_tables pt 
    WHERE pt.clinic_id = c.clinic_id 
    AND pt.name = c.name 
    AND pt.type = 'CONVENIO'
);

-- 4. Confirmação
SELECT '✅ Migração Price Tables Concluída' as status;
SELECT type, count(*) as total FROM public.price_tables GROUP BY type;
