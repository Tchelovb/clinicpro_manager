select id, status, total_value from budgets where id::text ilike 'ee5ab321%';
