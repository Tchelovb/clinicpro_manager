-- ============================================================
-- FIX DEFINITIVO V4.2: TABELA DE LOOKUP (COM CASCADE)
-- ============================================================

-- 0. Limpeza TOTAL usando CASCADE
-- Isso vai remover automaticamente todas as Policies que dependem dessas funções
DROP FUNCTION IF EXISTS public.get_role_safe(uuid) CASCADE;
DROP FUNCTION IF EXISTS public.get_clinic_safe(uuid) CASCADE;

-- 1. Criar tabela de lookup (espelho de permissões)
CREATE TABLE IF NOT EXISTS public.user_roles_lookup (
    user_id UUID PRIMARY KEY REFERENCES public.users(id) ON DELETE CASCADE,
    role role NOT NULL,
    clinic_id UUID REFERENCES public.clinics(id)
);

-- Tabela de lookup NÃO TEM RLS ativado (ou tem política true)
ALTER TABLE public.user_roles_lookup ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "public_read" ON public.user_roles_lookup;
CREATE POLICY "public_read" ON public.user_roles_lookup FOR SELECT TO authenticated USING (true);

-- 2. Popular tabela com dados existentes
INSERT INTO public.user_roles_lookup (user_id, role, clinic_id)
SELECT id, role, clinic_id FROM public.users
ON CONFLICT (user_id) DO UPDATE SET
    role = EXCLUDED.role,
    clinic_id = EXCLUDED.clinic_id;

-- 3. Trigger para manter sincronizado
CREATE OR REPLACE FUNCTION sync_user_roles_lookup()
RETURNS TRIGGER AS $$
BEGIN
    IF (TG_OP = 'DELETE') THEN
        DELETE FROM public.user_roles_lookup WHERE user_id = OLD.id;
        RETURN OLD;
    ELSIF (TG_OP = 'UPDATE' OR TG_OP = 'INSERT') THEN
        INSERT INTO public.user_roles_lookup (user_id, role, clinic_id)
        VALUES (NEW.id, NEW.role, NEW.clinic_id)
        ON CONFLICT (user_id) DO UPDATE SET
            role = EXCLUDED.role,
            clinic_id = EXCLUDED.clinic_id;
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_sync_user_roles ON public.users;
CREATE TRIGGER trg_sync_user_roles
AFTER INSERT OR UPDATE OR DELETE ON public.users
FOR EACH ROW EXECUTE FUNCTION sync_user_roles_lookup();

-- 4. Criar funções auxiliares que leem da LOOKUP (não da users)
CREATE OR REPLACE FUNCTION public.get_role_safe(uid UUID)
RETURNS TEXT STABLE LANGUAGE sql AS $$
    SELECT role::text FROM public.user_roles_lookup WHERE user_id = uid LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.get_clinic_safe(uid UUID)
RETURNS UUID STABLE LANGUAGE sql AS $$
    SELECT clinic_id FROM public.user_roles_lookup WHERE user_id = uid LIMIT 1;
$$;

-- 5. Atualizar TODAS as políticas RLS para usar as novas funções
-- Tabela USERS (agora seguro porque lê da lookup)
-- Nota: CASCADE ja deve ter removido as policies antigas, mas por segurança tentamos dropar
DROP POLICY IF EXISTS "clinic_isolation" ON public.users;
DROP POLICY IF EXISTS "users_policy" ON public.users;

-- Reabilitar RLS só pra garantir
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "users_policy" ON public.users 
FOR ALL USING (
    id = auth.uid() OR
    public.get_role_safe(auth.uid()) = 'MASTER' OR
    clinic_id = public.get_clinic_safe(auth.uid())
);

-- Tabela CLINICS
DROP POLICY IF EXISTS "clinic_isolation" ON public.clinics;
CREATE POLICY "clinic_isolation" ON public.clinics 
FOR ALL USING (
    public.get_role_safe(auth.uid()) = 'MASTER' OR
    id = public.get_clinic_safe(auth.uid())
);

-- Macro para outras tabelas
DO $$
DECLARE
    t text;
BEGIN
    FOR t IN 
        SELECT table_name 
        FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name IN ('patients', 'procedure', 'appointments', 'leads', 'financial_installments', 'expenses', 'transactions', 'professionals', 'price_tables', 'conventions', 'cash_registers')
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS "clinic_isolation" ON public.%I', t);
        EXECUTE format('
            CREATE POLICY "clinic_isolation" ON public.%I 
            FOR ALL USING (
                public.get_role_safe(auth.uid()) = ''MASTER''
                OR
                clinic_id = public.get_clinic_safe(auth.uid())
            )', t);
    END LOOP;
END $$;

-- Budgets
DROP POLICY IF EXISTS "clinic_isolation" ON public.budgets;
CREATE POLICY "clinic_isolation" ON public.budgets 
FOR ALL USING (
    public.get_role_safe(auth.uid()) = 'MASTER' OR
    patient_id IN (SELECT id FROM public.patients WHERE clinic_id = public.get_clinic_safe(auth.uid()))
);

SELECT '✅ FIX V4.2 APLICADO - CASCADE E RECRIAÇÃO TOTAL' as status;
