-- ============================================================
-- RESTORE USERS POLICY (PÓS-LIMPEZA)
-- ============================================================

-- 1. Redefinir funções de segurança com SECURITY DEFINER explícito
-- Isso garante que elas rodem com privilégios de dono, ignorando quaisquer restrições estranhas
CREATE OR REPLACE FUNCTION public.get_role_safe(uid UUID)
RETURNS TEXT 
SECURITY DEFINER
SET search_path = public
STABLE 
LANGUAGE sql 
AS $$
    SELECT role::text FROM public.user_roles_lookup WHERE user_id = uid LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.get_clinic_safe(uid UUID)
RETURNS UUID 
SECURITY DEFINER
SET search_path = public
STABLE 
LANGUAGE sql 
AS $$
    SELECT clinic_id FROM public.user_roles_lookup WHERE user_id = uid LIMIT 1;
$$;

-- 2. Garantir RLS ativado
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- 3. Limpeza de garantida (caso tenha sobrado algo)
DROP POLICY IF EXISTS "users_policy" ON public.users;
DROP POLICY IF EXISTS "clinic_isolation" ON public.users;
DROP POLICY IF EXISTS "Enable read access for authenticated users" ON public.users;

-- 4. Criar a política MÁGICA
-- Lê permissões da tabela LOOKUP, nunca da própria tabela USERS
CREATE POLICY "users_policy" ON public.users 
FOR ALL USING (
    -- 1. Auto-acesso (regra básica)
    id = auth.uid() 
    OR
    -- 2. MASTER (vê tudo via lookup)
    public.get_role_safe(auth.uid()) = 'MASTER' 
    OR
    -- 3. Clínica (vê pares via lookup)
    clinic_id = public.get_clinic_safe(auth.uid())
);

SELECT '✅ Política Restaurada Corretamente' as status;
