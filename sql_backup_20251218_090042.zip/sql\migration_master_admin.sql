-- ============================================================
-- Migration: Implementação Super Admin (MASTER)
-- Data: 17/12/2025
-- Descrição: Adiciona role MASTER e sistema de suspensão de clínicas
-- ============================================================

-- =================================================================
-- 1. ATUALIZAR ENUM ROLE
-- =================================================================

-- Adicionar valor MASTER ao enum role
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_enum 
        WHERE enumlabel = 'MASTER' 
        AND enumtypid = 'role'::regtype
    ) THEN
        ALTER TYPE role ADD VALUE 'MASTER';
    END IF;
END $$;

-- =================================================================
-- 2. ADICIONAR COLUNA STATUS NA TABELA CLINICS
-- =================================================================

-- Adicionar coluna status
ALTER TABLE public.clinics 
ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'ACTIVE' 
CHECK (status IN ('ACTIVE', 'SUSPENDED'));

-- Atualizar clínicas existentes para ACTIVE
UPDATE public.clinics SET status = 'ACTIVE' WHERE status IS NULL;

-- Criar índice para performance
CREATE INDEX IF NOT EXISTS idx_clinics_status ON public.clinics(status);

-- =================================================================
-- 3. ATUALIZAR RLS - TABELA USERS (Invisibilidade do Master)
-- =================================================================

-- Remover políticas antigas
DROP POLICY IF EXISTS "clinic_isolation" ON public.users;
DROP POLICY IF EXISTS "clinic_isolation_write" ON public.users;

-- Policy de SELECT: Usuários comuns não veem MASTER
CREATE POLICY "clinic_isolation" ON public.users 
  FOR SELECT USING (
    -- Se é MASTER, vê tudo
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    -- Se não é MASTER, vê apenas sua clínica E não vê outros MASTERS
    (
      clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
      AND role != 'MASTER'
    )
  );

-- Policy de INSERT/UPDATE/DELETE: MASTER pode tudo, outros apenas sua clínica
CREATE POLICY "clinic_isolation_write" ON public.users 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    (
      clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
      AND role != 'MASTER' -- Não pode editar MASTERS
    )
  );

-- =================================================================
-- 4. ATUALIZAR RLS - TABELA CLINICS (God Mode para Master)
-- =================================================================

-- Remover políticas antigas
DROP POLICY IF EXISTS "clinic_access" ON public.clinics;
DROP POLICY IF EXISTS "clinic_write" ON public.clinics;

-- MASTER vê todas as clínicas, outros veem apenas a sua
CREATE POLICY "clinic_access" ON public.clinics 
  FOR SELECT USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
  );

-- Apenas MASTER pode criar/editar clínicas
CREATE POLICY "clinic_write" ON public.clinics 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
  );

-- =================================================================
-- 5. ATUALIZAR RLS - DEMAIS TABELAS (God Mode)
-- =================================================================

-- Template: MASTER tem acesso total, outros filtrados por clinic_id

-- Tabela: patients
DROP POLICY IF EXISTS "clinic_isolation" ON public.patients;
CREATE POLICY "clinic_isolation" ON public.patients 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
  );

-- Tabela: appointments
DROP POLICY IF EXISTS "clinic_isolation" ON public.appointments;
CREATE POLICY "clinic_isolation" ON public.appointments 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
  );

-- Tabela: leads
DROP POLICY IF EXISTS "clinic_isolation" ON public.leads;
CREATE POLICY "clinic_isolation" ON public.leads 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
  );

-- Tabela: budgets
DROP POLICY IF EXISTS "clinic_isolation" ON public.budgets;
CREATE POLICY "clinic_isolation" ON public.budgets 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    EXISTS (
      SELECT 1 FROM public.patients 
      WHERE id = budgets.patient_id 
      AND clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
    )
  );

-- Tabela: budget_items
DROP POLICY IF EXISTS "clinic_isolation" ON public.budget_items;
CREATE POLICY "clinic_isolation" ON public.budget_items 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    EXISTS (
      SELECT 1 FROM public.budgets b
      JOIN public.patients p ON b.patient_id = p.id
      WHERE b.id = budget_items.budget_id 
      AND p.clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
    )
  );

-- Tabela: treatment_items
DROP POLICY IF EXISTS "clinic_isolation" ON public.treatment_items;
CREATE POLICY "clinic_isolation" ON public.treatment_items 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    EXISTS (
      SELECT 1 FROM public.patients 
      WHERE id = treatment_items.patient_id 
      AND clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
    )
  );

-- Tabela: financial_installments
DROP POLICY IF EXISTS "clinic_isolation" ON public.financial_installments;
CREATE POLICY "clinic_isolation" ON public.financial_installments 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
  );

-- Tabela: expenses
DROP POLICY IF EXISTS "clinic_isolation" ON public.expenses;
CREATE POLICY "clinic_isolation" ON public.expenses 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
  );

-- Tabela: transactions
DROP POLICY IF EXISTS "clinic_isolation" ON public.transactions;
CREATE POLICY "clinic_isolation" ON public.transactions 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
  );

-- Tabela: cash_registers
DROP POLICY IF EXISTS "clinic_isolation" ON public.cash_registers;
CREATE POLICY "clinic_isolation" ON public.cash_registers 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
  );

-- Tabela: payment_history
DROP POLICY IF EXISTS "clinic_isolation" ON public.payment_history;
CREATE POLICY "clinic_isolation" ON public.payment_history 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    EXISTS (
      SELECT 1 FROM public.financial_installments 
      WHERE id = payment_history.installment_id 
      AND clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
    )
  );

-- Tabela: procedure
DROP POLICY IF EXISTS "clinic_isolation" ON public.procedure;
CREATE POLICY "clinic_isolation" ON public.procedure 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
  );

-- Tabela: price_tables
DROP POLICY IF EXISTS "clinic_isolation" ON public.price_tables;
CREATE POLICY "clinic_isolation" ON public.price_tables 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
  );

-- Tabela: price_table_items
DROP POLICY IF EXISTS "clinic_isolation" ON public.price_table_items;
CREATE POLICY "clinic_isolation" ON public.price_table_items 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    EXISTS (
      SELECT 1 FROM public.price_tables 
      WHERE id = price_table_items.price_table_id 
      AND clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
    )
  );

-- Tabela: conventions
DROP POLICY IF EXISTS "clinic_isolation" ON public.conventions;
CREATE POLICY "clinic_isolation" ON public.conventions 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
  );

-- Tabela: insurance_plans
DROP POLICY IF EXISTS "clinic_isolation" ON public.insurance_plans;
CREATE POLICY "clinic_isolation" ON public.insurance_plans 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
  );

-- Tabela: professionals
DROP POLICY IF EXISTS "clinic_isolation" ON public.professionals;
CREATE POLICY "clinic_isolation" ON public.professionals 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
  );

-- Tabela: professional_schedules
DROP POLICY IF EXISTS "clinic_isolation" ON public.professional_schedules;
CREATE POLICY "clinic_isolation" ON public.professional_schedules 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
  );

-- Tabela: document_templates
DROP POLICY IF EXISTS "clinic_isolation" ON public.document_templates;
CREATE POLICY "clinic_isolation" ON public.document_templates 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
  );

-- Tabela: patient_documents
DROP POLICY IF EXISTS "clinic_isolation" ON public.patient_documents;
CREATE POLICY "clinic_isolation" ON public.patient_documents 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    EXISTS (
      SELECT 1 FROM public.patients 
      WHERE id = patient_documents.patient_id 
      AND clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
    )
  );

-- Tabela: clinical_notes
DROP POLICY IF EXISTS "clinic_isolation" ON public.clinical_notes;
CREATE POLICY "clinic_isolation" ON public.clinical_notes 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    EXISTS (
      SELECT 1 FROM public.patients 
      WHERE id = clinical_notes.patient_id 
      AND clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
    )
  );

-- Tabela: lead_interactions
DROP POLICY IF EXISTS "clinic_isolation" ON public.lead_interactions;
CREATE POLICY "clinic_isolation" ON public.lead_interactions 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    EXISTS (
      SELECT 1 FROM public.leads 
      WHERE id = lead_interactions.lead_id 
      AND clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
    )
  );

-- Tabela: lead_tasks
DROP POLICY IF EXISTS "clinic_isolation" ON public.lead_tasks;
CREATE POLICY "clinic_isolation" ON public.lead_tasks 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    EXISTS (
      SELECT 1 FROM public.leads 
      WHERE id = lead_tasks.lead_id 
      AND clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
    )
  );

-- Tabela: lead_source
DROP POLICY IF EXISTS "clinic_isolation" ON public.lead_source;
CREATE POLICY "clinic_isolation" ON public.lead_source 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
  );

-- Tabela: custom_lead_status
DROP POLICY IF EXISTS "clinic_isolation" ON public.custom_lead_status;
CREATE POLICY "clinic_isolation" ON public.custom_lead_status 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
  );

-- Tabela: expense_category
DROP POLICY IF EXISTS "clinic_isolation" ON public.expense_category;
CREATE POLICY "clinic_isolation" ON public.expense_category 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
  );

-- Tabela: revenue_category
DROP POLICY IF EXISTS "clinic_isolation" ON public.revenue_category;
CREATE POLICY "clinic_isolation" ON public.revenue_category 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
  );

-- Tabela: payment_method
DROP POLICY IF EXISTS "clinic_isolation" ON public.payment_method;
CREATE POLICY "clinic_isolation" ON public.payment_method 
  FOR ALL USING (
    (SELECT role FROM public.users WHERE id = auth.uid()) = 'MASTER'
    OR
    clinic_id = (SELECT clinic_id FROM public.users WHERE id = auth.uid())
  );

-- =================================================================
-- 6. COMENTÁRIOS E DOCUMENTAÇÃO
-- =================================================================

COMMENT ON COLUMN public.clinics.status IS 'Status da clínica: ACTIVE (ativa) ou SUSPENDED (suspensa por inadimplência)';
COMMENT ON TYPE role IS 'Roles do sistema: ADMIN (administrador da clínica), DENTIST (dentista), RECEPTIONIST (recepcionista), ASSISTANT (auxiliar), MASTER (super admin SaaS)';

-- =================================================================
-- FIM DA MIGRATION
-- =================================================================

-- Para aplicar esta migration no Supabase:
-- 1. Acesse o SQL Editor no painel do Supabase
-- 2. Cole todo este código
-- 3. Execute
-- 4. Verifique se não há erros
-- 5. Teste criando um usuário MASTER
