-- ============================================================
-- FIX DEFINITIVO V2: RECURSÃO RLS NA TABELA USERS
-- Estratégia: Simplificar a política e usar funções limpas
-- ============================================================

-- 1. Criar funções SEGURAS com nomes novos para garantir limpeza
CREATE OR REPLACE FUNCTION public.get_role_safe(user_id UUID)
RETURNS TEXT
SECURITY DEFINER
SET search_path = public
LANGUAGE sql
STABLE
AS $$
    SELECT role::text FROM public.users WHERE id = user_id LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.get_clinic_safe(user_id UUID)
RETURNS UUID
SECURITY DEFINER
SET search_path = public
LANGUAGE sql
STABLE
AS $$
    SELECT clinic_id FROM public.users WHERE id = user_id LIMIT 1;
$$;

-- 2. Desabilitar e reabilitar RLS para limpar caches
ALTER TABLE public.users DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- 3. Remover política antiga problemática
DROP POLICY IF EXISTS "clinic_isolation" ON public.users;

-- 4. Criar NOVA política otimizada para a tabela USERS
-- A ordem das condições importa! 
CREATE POLICY "users_policy" ON public.users 
FOR ALL USING (
    -- 1. Regra base anti-recursão: Usuário sempre vê a si mesmo (sem chamar funções)
    id = auth.uid()
    OR
    -- 2. MASTER vê tudo (usando função segura)
    public.get_role_safe(auth.uid()) = 'MASTER'
    OR
    -- 3. Colegas da mesma clínica (usando função segura)
    clinic_id = public.get_clinic_safe(auth.uid())
);

-- 5. Atualizar as outras tabelas para usar as novas funções seguras
-- (Isso garante consistência)

-- Helper macro para recriar policies
DO $$
DECLARE
    t text;
BEGIN
    FOR t IN 
        SELECT table_name 
        FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name IN ('clinics', 'patients', 'procedure', 'appointments', 'leads', 'financial_installments', 'expenses', 'transactions', 'professionals', 'price_tables', 'conventions', 'cash_registers')
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS "clinic_isolation" ON public.%I', t);
        EXECUTE format('
            CREATE POLICY "clinic_isolation" ON public.%I 
            FOR ALL USING (
                public.get_role_safe(auth.uid()) = ''MASTER''
                OR
                clinic_id = public.get_clinic_safe(auth.uid())
            )', t);
    END LOOP;
END $$;

-- Atualizar budgets (tem lógica diferente)
DROP POLICY IF EXISTS "clinic_isolation" ON public.budgets;
CREATE POLICY "clinic_isolation" ON public.budgets 
FOR ALL USING (
    public.get_role_safe(auth.uid()) = 'MASTER'
    OR
    patient_id IN (
        SELECT id FROM public.patients 
        WHERE clinic_id = public.get_clinic_safe(auth.uid())
    )
);

SELECT '✅ FIX V2 APLICADO - FUNÇÕES SEGURAS E POLÍTICA OTIMIZADA' as status;
