-- ============================================================
-- FIX DEFINITIVO V3 (SEM LOOP): RECURSÃO RLS REFORMULADA
-- ============================================================

-- 1. Criar funções SEGURAS (se ja nao existirem)
CREATE OR REPLACE FUNCTION public.get_role_safe(user_id UUID)
RETURNS TEXT
SECURITY DEFINER
SET search_path = public
LANGUAGE sql
STABLE
AS $$
    SELECT role::text FROM public.users WHERE id = user_id LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.get_clinic_safe(user_id UUID)
RETURNS UUID
SECURITY DEFINER
SET search_path = public
LANGUAGE sql
STABLE
AS $$
    SELECT clinic_id FROM public.users WHERE id = user_id LIMIT 1;
$$;

-- 2. RESETAR RLS DA TABELA USERS (Causa raiz da recursão)
ALTER TABLE public.users DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "clinic_isolation" ON public.users;
DROP POLICY IF EXISTS "users_policy" ON public.users;

-- 3. POLÍTICA OTIMIZADA PARA USERS
-- Ordem CRÍTICA: Primeiro id=auth.uid() para evitar recursão
CREATE POLICY "users_policy" ON public.users 
FOR ALL USING (
    id = auth.uid() OR
    public.get_role_safe(auth.uid()) = 'MASTER' OR
    clinic_id = public.get_clinic_safe(auth.uid())
);

-- 4. POLÍTICA PARA CLINICS (Usa 'id' nao 'clinic_id')
DROP POLICY IF EXISTS "clinic_isolation" ON public.clinics;
CREATE POLICY "clinic_isolation" ON public.clinics 
FOR ALL USING (
    public.get_role_safe(auth.uid()) = 'MASTER' OR
    id = public.get_clinic_safe(auth.uid())
);

-- 5. POLÍTICAS PARA TABELAS PADRÃO (Usam 'clinic_id')
-- Patients
DROP POLICY IF EXISTS "clinic_isolation" ON public.patients;
CREATE POLICY "clinic_isolation" ON public.patients 
FOR ALL USING (public.get_role_safe(auth.uid()) = 'MASTER' OR clinic_id = public.get_clinic_safe(auth.uid()));

-- Procedure
DROP POLICY IF EXISTS "clinic_isolation" ON public.procedure;
CREATE POLICY "clinic_isolation" ON public.procedure 
FOR ALL USING (public.get_role_safe(auth.uid()) = 'MASTER' OR clinic_id = public.get_clinic_safe(auth.uid()));

-- Appointments
DROP POLICY IF EXISTS "clinic_isolation" ON public.appointments;
CREATE POLICY "clinic_isolation" ON public.appointments 
FOR ALL USING (public.get_role_safe(auth.uid()) = 'MASTER' OR clinic_id = public.get_clinic_safe(auth.uid()));

-- Leads
DROP POLICY IF EXISTS "clinic_isolation" ON public.leads;
CREATE POLICY "clinic_isolation" ON public.leads 
FOR ALL USING (public.get_role_safe(auth.uid()) = 'MASTER' OR clinic_id = public.get_clinic_safe(auth.uid()));

-- Financial Installments
DROP POLICY IF EXISTS "clinic_isolation" ON public.financial_installments;
CREATE POLICY "clinic_isolation" ON public.financial_installments 
FOR ALL USING (public.get_role_safe(auth.uid()) = 'MASTER' OR clinic_id = public.get_clinic_safe(auth.uid()));

-- Expenses
DROP POLICY IF EXISTS "clinic_isolation" ON public.expenses;
CREATE POLICY "clinic_isolation" ON public.expenses 
FOR ALL USING (public.get_role_safe(auth.uid()) = 'MASTER' OR clinic_id = public.get_clinic_safe(auth.uid()));

-- Transactions
DROP POLICY IF EXISTS "clinic_isolation" ON public.transactions;
CREATE POLICY "clinic_isolation" ON public.transactions 
FOR ALL USING (public.get_role_safe(auth.uid()) = 'MASTER' OR clinic_id = public.get_clinic_safe(auth.uid()));

-- Professionals
DROP POLICY IF EXISTS "clinic_isolation" ON public.professionals;
CREATE POLICY "clinic_isolation" ON public.professionals 
FOR ALL USING (public.get_role_safe(auth.uid()) = 'MASTER' OR clinic_id = public.get_clinic_safe(auth.uid()));

-- Price Tables
DROP POLICY IF EXISTS "clinic_isolation" ON public.price_tables;
CREATE POLICY "clinic_isolation" ON public.price_tables 
FOR ALL USING (public.get_role_safe(auth.uid()) = 'MASTER' OR clinic_id = public.get_clinic_safe(auth.uid()));

-- Conventions
DROP POLICY IF EXISTS "clinic_isolation" ON public.conventions;
CREATE POLICY "clinic_isolation" ON public.conventions 
FOR ALL USING (public.get_role_safe(auth.uid()) = 'MASTER' OR clinic_id = public.get_clinic_safe(auth.uid()));

-- Cash Registers
DROP POLICY IF EXISTS "clinic_isolation" ON public.cash_registers;
CREATE POLICY "clinic_isolation" ON public.cash_registers 
FOR ALL USING (public.get_role_safe(auth.uid()) = 'MASTER' OR clinic_id = public.get_clinic_safe(auth.uid()));

-- Budgets (Lógica especial via patient_id)
DROP POLICY IF EXISTS "clinic_isolation" ON public.budgets;
CREATE POLICY "clinic_isolation" ON public.budgets 
FOR ALL USING (
    public.get_role_safe(auth.uid()) = 'MASTER' OR
    patient_id IN (SELECT id FROM public.patients WHERE clinic_id = public.get_clinic_safe(auth.uid()))
);

SELECT '✅ FIX V3 APLICADO - SEM ERRO DE COLUNA' as status;
