-- ============================================================
-- SOLUÇÃO NUCLEAR - LIMPEZA TOTAL E SETUP
-- Execute este script para resolver de vez
-- ============================================================

DO $$ 
DECLARE
    _trigger_name text;
    _sql text;
BEGIN
    -- 1. Encontrar e remover TODOS os triggers da tabela clinics (exceto constraints do sistema)
    FOR _trigger_name IN 
        SELECT trigger_name 
        FROM information_schema.triggers 
        WHERE event_object_table = 'clinics' 
        AND trigger_schema = 'public'
    LOOP
        _sql := 'DROP TRIGGER IF EXISTS ' || quote_ident(_trigger_name) || ' ON public.clinics CASCADE;';
        RAISE NOTICE 'Removendo trigger: %', _trigger_name;
        EXECUTE _sql;
    END LOOP;

    -- 2. Garantir que a coluna updated_at existe
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'clinics' AND column_name = 'updated_at'
    ) THEN
        ALTER TABLE public.clinics ADD COLUMN updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();
        RAISE NOTICE 'Coluna updated_at criada.';
    ELSE
        RAISE NOTICE 'Coluna updated_at já existia.';
    END IF;

    -- 3. Adicionar role MASTER (se não existir)
    IF NOT EXISTS (
        SELECT 1 FROM pg_type t 
        JOIN pg_enum e ON t.oid = e.enumtypid 
        WHERE t.typname = 'role' AND e.enumlabel = 'MASTER'
    ) THEN
        ALTER TYPE role ADD VALUE 'MASTER';
        RAISE NOTICE 'Role MASTER criada.';
    END IF;
END $$;

-- 4. Criar a clínica MASTER (Agora sem triggers para atrapalhar!)
INSERT INTO public.clinics (id, name, cnpj, code, status, created_at, updated_at)
VALUES (
    '00000000-0000-0000-0000-000000000000', 
    'CLINICPRO GESTÃO GLOBAL', 
    '00.000.000/0001-00',
    'MASTER', 
    'ACTIVE',
    NOW(),
    NOW()
)
ON CONFLICT (id) DO UPDATE SET
    name = EXCLUDED.name,
    code = EXCLUDED.code,
    status = EXCLUDED.status;

-- 5. Elevar o usuário para MASTER
UPDATE public.users 
SET 
    role = 'MASTER', 
    clinic_id = '00000000-0000-0000-0000-000000000000'
WHERE email = 'master@clinicpro.com';

-- 6. (Opcional) Recriar um trigger limpo e funcional
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_clinics_updated_at
    BEFORE UPDATE ON public.clinics
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================================
-- VERIFICAÇÃO FINAL
-- ============================================================
SELECT 
    '✅ SUCESSO TOTAL' as status,
    u.email, u.role, c.code
FROM public.users u
JOIN public.clinics c ON u.clinic_id = c.id
WHERE u.email = 'master@clinicpro.com';
