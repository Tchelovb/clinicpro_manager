-- DIAGNOSTIC: CHECK FOR updated_at COLUMN
-- Checks if 'updated_at' exists on critical tables

SELECT table_name, column_name 
FROM information_schema.columns 
WHERE table_schema = 'public' 
  AND column_name = 'updated_at'
  AND table_name IN ('users', 'professionals', 'user_roles_lookup', 'clinics');

-- LIST TRIGGERS
SELECT event_object_table as table_name, trigger_name
FROM information_schema.triggers
WHERE event_object_table IN ('users', 'professionals', 'user_roles_lookup', 'clinics');
