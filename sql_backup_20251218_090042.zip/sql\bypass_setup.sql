-- ============================================================
-- BYPASS FUNCTION SETUP
-- Estratégia: Esvaziar a função do trigger para que ela não faça nada
-- ============================================================

-- 1. Redefinir a função culpada para NÃO FAZER NADA temporariamente
-- Isso neutraliza qualquer trigger que esteja usando ela, em qualquer tabela!
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    -- Não faz nada com updated_at
    -- Apenas retorna o registro original
    RETURN NEW; 
END;
$$ LANGUAGE plpgsql;

-- 2. Garantir que a coluna updated_at existe na tabela clinics
ALTER TABLE public.clinics 
ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();

-- 3. Agora podemos fazer o INSERT tranquilamente
-- Mesmo que o trigger dispare, a função não vai tentar acessar 'updated_at' erradamente
INSERT INTO public.clinics (id, name, cnpj, code, status, created_at)
VALUES (
    '00000000-0000-0000-0000-000000000000', 
    'CLINICPRO GESTÃO GLOBAL', 
    '00.000.000/0001-00',
    'MASTER', 
    'ACTIVE',
    NOW()
)
ON CONFLICT (id) DO UPDATE SET
    name = EXCLUDED.name,
    code = EXCLUDED.code,
    status = EXCLUDED.status;

-- 4. Adicionar role MASTER se não existir
DO $$ 
BEGIN 
    IF NOT EXISTS (
        SELECT 1 FROM pg_type t 
        JOIN pg_enum e ON t.oid = e.enumtypid 
        WHERE t.typname = 'role' AND e.enumlabel = 'MASTER'
    ) THEN
        ALTER TYPE role ADD VALUE 'MASTER';
    END IF;
END $$;

-- 5. Elevar o usuário MASTER
UPDATE public.users 
SET 
    role = 'MASTER', 
    clinic_id = '00000000-0000-0000-0000-000000000000'
WHERE email = 'master@clinicpro.com';

-- 6. Restaurar a função correta do trigger
-- Agora que a coluna já existe, é seguro restaurar
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 7. Verificar sucesso
SELECT '✅ SETUP CONCLUÍDO COM SUCESSO' as status;
