-- STRICT FIX: RESOLVE CONSTRAINT BLOCKERS
-- Warning: This script aggressively fixes data to satisfy the schema.

-- 1. FORCE CLEANUP: Remove invalid Professional IDs
UPDATE public.users 
SET professional_id = NULL 
WHERE role IN ('RECEPTIONIST', 'ASSISTANT');

-- 2. CREATE MISSING PROFESSIONALS (One last try, matching by name)
INSERT INTO public.professionals (clinic_id, name, is_active)
SELECT clinic_id, name, active
FROM public.users
WHERE role = 'DENTIST' 
  AND professional_id IS NULL;

-- 3. LINK THEM
UPDATE public.users u
SET professional_id = p.id
FROM public.professionals p
WHERE u.role = 'DENTIST' 
  AND u.professional_id IS NULL 
  AND u.name = p.name 
  AND u.clinic_id = p.clinic_id;

-- 4. NUCLEAR OPTION: Downgrade remaining invalid Dentists to ADMIN
-- If we still can't find/create a professional for them, they cannot be DENTISTs.
-- We default them to ADMIN so the constraint passes and they can be fixed later in UI.
UPDATE public.users
SET role = 'ADMIN'
WHERE role = 'DENTIST' AND professional_id IS NULL;

-- 5. APPLY CONSTRAINT
ALTER TABLE public.users DROP CONSTRAINT IF EXISTS check_professional_role_link;
ALTER TABLE public.users ADD CONSTRAINT check_professional_role_link CHECK (
  (role = 'DENTIST' AND professional_id IS NOT NULL) OR
  (role = 'ADMIN') OR 
  (role IN ('RECEPTIONIST', 'ASSISTANT') AND professional_id IS NULL)
);

-- 6. MIGRATE SCHEDULES
-- (Assuming professional_id is now populated for all remaining Dentists)
ALTER TABLE public.professional_schedules ADD COLUMN IF NOT EXISTS new_prof_id UUID;

UPDATE public.professional_schedules ps
SET new_prof_id = u.professional_id
FROM public.users u
WHERE ps.professional_id = u.id;

DELETE FROM public.professional_schedules WHERE new_prof_id IS NULL;

ALTER TABLE public.professional_schedules DROP CONSTRAINT IF EXISTS professional_schedules_professional_id_fkey;
ALTER TABLE public.professional_schedules DROP COLUMN professional_id;
ALTER TABLE public.professional_schedules RENAME COLUMN new_prof_id TO professional_id;

ALTER TABLE public.professional_schedules 
ADD CONSTRAINT professional_schedules_professional_id_fkey 
FOREIGN KEY (professional_id) REFERENCES public.professionals(id) ON DELETE CASCADE;

-- 7. RECREATE RPC
CREATE OR REPLACE FUNCTION public.manage_user_professional(
    p_user_id UUID, 
    p_clinic_id UUID,
    p_name TEXT,
    p_email TEXT,
    p_role role,
    p_color TEXT,
    p_active BOOLEAN,
    p_professional_data JSONB 
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID;
    v_prof_id UUID;
BEGIN
    IF p_user_id IS NULL THEN
        v_user_id := uuid_generate_v4(); 
    ELSE
        v_user_id := p_user_id;
    END IF;

    IF (p_role = 'DENTIST') OR (p_role = 'ADMIN' AND p_professional_data IS NOT NULL) THEN
        SELECT professional_id INTO v_prof_id FROM public.users WHERE id = v_user_id;
        
        IF v_prof_id IS NOT NULL THEN
            UPDATE public.professionals
            SET 
                name = p_name, 
                crc = p_professional_data->>'council_number',
                council = p_professional_data->>'council_type',
                specialty = p_professional_data->>'specialty',
                color = p_color,
                is_active = p_active
            WHERE id = v_prof_id;
        ELSE
            INSERT INTO public.professionals (
                clinic_id, name, crc, council, specialty, color, is_active
            ) VALUES (
                p_clinic_id,
                p_name,
                p_professional_data->>'council_number',
                p_professional_data->>'council_type',
                p_professional_data->>'specialty',
                p_color,
                p_active
            ) RETURNING id INTO v_prof_id;
        END IF;

    ELSE
        v_prof_id := NULL;
    END IF;

    INSERT INTO public.users (
        id, clinic_id, email, name, role, color, active, professional_id
    ) VALUES (
        v_user_id, p_clinic_id, p_email, p_name, p_role, p_color, p_active, v_prof_id
    )
    ON CONFLICT (id) DO UPDATE SET
        name = EXCLUDED.name,
        email = EXCLUDED.email,
        role = EXCLUDED.role,
        color = EXCLUDED.color,
        active = EXCLUDED.active,
        professional_id = v_prof_id;

    RETURN jsonb_build_object('user_id', v_user_id, 'professional_id', v_prof_id);
END;
$$;
