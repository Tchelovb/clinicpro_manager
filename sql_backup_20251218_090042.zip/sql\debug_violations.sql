-- DEBUG SCRIPT: FIND CONSTRAINT VIOLATORS
-- Run this to see exactly which users are failing the validation

SELECT id, name, email, role, professional_id
FROM public.users
WHERE 
    -- Case 1: DENTIST without Professional ID
    (role = 'DENTIST' AND professional_id IS NULL)
    OR
    -- Case 2: RECEPTIONIST/ASSISTANT with Professional ID
    (role IN ('RECEPTIONIST', 'ASSISTANT') AND professional_id IS NOT NULL);
