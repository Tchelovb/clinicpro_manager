-- DEEP DIAGNOSTIC: COLUMNS AND TRIGGERS
-- List columns for key tables to verify 'updated_at' existence
SELECT table_name, column_name, data_type
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name IN ('users', 'professionals', 'user_roles_lookup');

-- List all triggers using the generic update function
SELECT 
    event_object_table as table_name, 
    trigger_name
FROM information_schema.triggers
WHERE action_statement LIKE '%update_updated_at_column%';
