-- ============================================================
-- REMOVER TRIGGER PROBLEMÁTICO
-- Execute este script PRIMEIRO
-- ============================================================

-- Remover o trigger que está causando o erro
DROP TRIGGER IF EXISTS update_clinics_updated_at ON public.clinics;
DROP TRIGGER IF EXISTS set_updated_at ON public.clinics;
DROP TRIGGER IF EXISTS update_clinics_modtime ON public.clinics;

-- Verificar que os triggers foram removidos
SELECT 
    '✅ Triggers removidos com sucesso' as status,
    COUNT(*) as triggers_restantes
FROM information_schema.triggers
WHERE event_object_table = 'clinics'
AND trigger_name LIKE '%updated%';
