-- ============================================================
-- MASTER SETUP - FIX PARA TRIGGER UPDATED_AT
-- Execute este script PRIMEIRO para corrigir o problema do trigger
-- ============================================================

-- 1. Remover o trigger problemático da tabela clinics (se existir)
DROP TRIGGER IF EXISTS update_clinics_updated_at ON public.clinics;

-- 2. Adicionar a coluna updated_at se não existir
DO $$ 
BEGIN 
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'clinics' 
        AND column_name = 'updated_at'
    ) THEN
        ALTER TABLE public.clinics 
        ADD COLUMN updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();
    END IF;
END $$;

-- 3. Recriar o trigger corretamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_clinics_updated_at
    BEFORE UPDATE ON public.clinics
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================================
-- AGORA EXECUTE O SETUP MASTER
-- ============================================================

-- 4. Adicionar MASTER ao enum role
DO $$ 
BEGIN 
    IF NOT EXISTS (
        SELECT 1 FROM pg_type t 
        JOIN pg_enum e ON t.oid = e.enumtypid 
        WHERE t.typname = 'role' AND e.enumlabel = 'MASTER'
    ) THEN
        ALTER TYPE role ADD VALUE 'MASTER';
    END IF;
END $$;

-- 5. Criar clínica MASTER
INSERT INTO public.clinics (id, name, cnpj, code, status)
VALUES (
    '00000000-0000-0000-0000-000000000000', 
    'CLINICPRO GESTÃO GLOBAL', 
    '00.000.000/0001-00',
    'MASTER', 
    'ACTIVE'
)
ON CONFLICT (id) DO UPDATE SET
    name = EXCLUDED.name,
    code = EXCLUDED.code,
    status = EXCLUDED.status;

-- 6. Elevar seu usuário a MASTER
-- Email configurado: master@clinicpro.com
UPDATE public.users 
SET 
    role = 'MASTER', 
    clinic_id = '00000000-0000-0000-0000-000000000000'
WHERE email = 'master@clinicpro.com';

-- 7. Verificar se funcionou
SELECT 
    '=== CLÍNICA MASTER ===' as info,
    id, name, code, status
FROM public.clinics
WHERE code = 'MASTER';

SELECT 
    '=== USUÁRIOS MASTER ===' as info,
    u.id, u.email, u.name, u.role, 
    c.name as clinica, c.code
FROM public.users u
LEFT JOIN public.clinics c ON u.clinic_id = c.id
WHERE u.role = 'MASTER';
