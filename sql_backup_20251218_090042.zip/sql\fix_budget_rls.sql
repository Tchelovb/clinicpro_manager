-- FIX: RLS FOR BUDGETS and INSTALLMENTS
-- Description: Ensures budgets table has proper RLS policies allowing DELETE/UPDATE/SELECT based on Clinic via Patient.

-- 1. Policy for BUDGETS
ALTER TABLE public.budgets ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "clinic_isolation_budgets" ON public.budgets;
CREATE POLICY "clinic_isolation_budgets" ON public.budgets
FOR ALL
USING (
    patient_id IN (
        SELECT id FROM public.patients 
        WHERE clinic_id IN (
            SELECT clinic_id FROM public.users WHERE id = auth.uid()
        )
    )
);

-- 2. Policy for FINANCIAL_INSTALLMENTS (ensure DELETE works)
ALTER TABLE public.financial_installments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "clinic_isolation_installments" ON public.financial_installments;
CREATE POLICY "clinic_isolation_installments" ON public.financial_installments
FOR ALL
USING (
    clinic_id IN (
        SELECT clinic_id FROM public.users WHERE id = auth.uid()
    )
);

-- 3. Policy for TREATMENT_ITEMS
ALTER TABLE public.treatment_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "clinic_isolation_treatments" ON public.treatment_items;
CREATE POLICY "clinic_isolation_treatments" ON public.treatment_items
FOR ALL
USING (
    patient_id IN (
        SELECT id FROM public.patients 
        WHERE clinic_id IN (
            SELECT clinic_id FROM public.users WHERE id = auth.uid()
        )
    )
);

-- 4. Policy for BUDGET_ITEMS
ALTER TABLE public.budget_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "clinic_isolation_budget_items" ON public.budget_items;
CREATE POLICY "clinic_isolation_budget_items" ON public.budget_items
FOR ALL
USING (
    budget_id IN (
        SELECT id FROM public.budgets 
        WHERE patient_id IN (
            SELECT id FROM public.patients 
            WHERE clinic_id IN (
                SELECT clinic_id FROM public.users WHERE id = auth.uid()
            )
        )
    )
);
