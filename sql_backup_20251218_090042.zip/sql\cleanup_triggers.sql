-- FIX: CLEANUP TRIGGERS
-- Description: Removes redundant triggers causing conflicts and potential missing column errors.

-- 1. Remove Legacy/Duplicate Triggers on USERS
DROP TRIGGER IF EXISTS update_users_updated_at ON public.users;
-- Keep 'update_users_modtime' which we control.

-- 2. Remove Trigger on USER_ROLES_LOOKUP (Potential Source of Error)
-- We will manage updated_at manually or ignore it for this lookup table to prevent the error.
DROP TRIGGER IF EXISTS update_user_roles_lookup_modtime ON public.user_roles_lookup;

-- 3. Ensure 'updated_at' column exists on USER_ROLES_LOOKUP (Just in case)
ALTER TABLE public.user_roles_lookup ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();

-- 4. Cleanup other potential duplicates based on your list
DROP TRIGGER IF EXISTS update_professionals_updated_at ON public.professionals; -- If it exists
DROP TRIGGER IF EXISTS update_clinics_updated_at ON public.clinics; -- If it exists

-- 5. Verify user_roles_lookup sync trigger
-- Ensure the sync trigger on users is still there (it wasn't in the list, but 'sync_user_roles' should occur AFTER INSERT/UPDATE)
-- (No action needed, just cleaning up the 'updated_at' noise)
