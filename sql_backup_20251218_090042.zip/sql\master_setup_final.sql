-- ============================================================
-- MASTER SETUP COMPLETO
-- Execute DEPOIS de add_updated_at_column.sql
-- ============================================================

-- 1. Adicionar MASTER ao enum role
DO $$ 
BEGIN 
    IF NOT EXISTS (
        SELECT 1 FROM pg_type t 
        JOIN pg_enum e ON t.oid = e.enumtypid 
        WHERE t.typname = 'role' AND e.enumlabel = 'MASTER'
    ) THEN
        ALTER TYPE role ADD VALUE 'MASTER';
    END IF;
END $$;

-- 2. Criar clínica MASTER
INSERT INTO public.clinics (id, name, cnpj, code, status, created_at, updated_at)
VALUES (
    '00000000-0000-0000-0000-000000000000', 
    'CLINICPRO GESTÃO GLOBAL', 
    '00.000.000/0001-00',
    'MASTER', 
    'ACTIVE',
    NOW(),
    NOW()
)
ON CONFLICT (id) DO NOTHING;

-- 3. Elevar usuário master@clinicpro.com para MASTER
UPDATE public.users 
SET 
    role = 'MASTER', 
    clinic_id = '00000000-0000-0000-0000-000000000000'
WHERE email = 'master@clinicpro.com';

-- ============================================================
-- VERIFICAÇÕES
-- ============================================================

SELECT '=== ✅ CLÍNICA MASTER ===' as status;
SELECT id, name, code, status, created_at, updated_at
FROM public.clinics
WHERE code = 'MASTER';

SELECT '=== ✅ USUÁRIO MASTER ===' as status;
SELECT 
    u.id, u.email, u.name, u.role, 
    c.name as clinica_nome, c.code as clinica_codigo
FROM public.users u
LEFT JOIN public.clinics c ON u.clinic_id = c.id
WHERE u.email = 'master@clinicpro.com';
