-- =================================================================
-- FIX: PROFESSIONAL ENTITY REFACTOR (ROBUST VERSION)
-- Description: Handles migration with guaranteed linking using ID tracking
-- =================================================================

-- 1. CLEANUP INVALID DATA (Receptionists/Assistants should not have professional_id)
UPDATE public.users 
SET professional_id = NULL 
WHERE role IN ('RECEPTIONIST', 'ASSISTANT');

-- 2. CREATE MISSING PROFESSIONALS FOR DENTISTS (Robust Method)
-- We add a temporary column to track exactly which user generated which professional
ALTER TABLE public.professionals ADD COLUMN IF NOT EXISTS temp_user_origin UUID;

-- Insert professionals for Dentists who have no link, tracking their ID
INSERT INTO public.professionals (clinic_id, name, is_active, temp_user_origin)
SELECT clinic_id, name, active, id
FROM public.users
WHERE role = 'DENTIST' AND professional_id IS NULL;

-- Update users using the tracking ID (Guaranteed Match)
UPDATE public.users u
SET professional_id = p.id
FROM public.professionals p
WHERE p.temp_user_origin = u.id;

-- Cleanup the temp column
ALTER TABLE public.professionals DROP COLUMN temp_user_origin;

-- 3. MIGRATE PROFESSIONAL SCHEDULES (Optimized)
-- Now that all Dentists have professional_id, we can safely migrate schedules
ALTER TABLE public.professional_schedules ADD COLUMN IF NOT EXISTS new_prof_id UUID;

UPDATE public.professional_schedules ps
SET new_prof_id = u.professional_id
FROM public.users u
WHERE ps.professional_id = u.id;

-- Allow NULLs temporarily if necessary, but ideally we delete orphans
DELETE FROM public.professional_schedules WHERE new_prof_id IS NULL;

-- Swap columns
ALTER TABLE public.professional_schedules DROP CONSTRAINT IF EXISTS professional_schedules_professional_id_fkey;
ALTER TABLE public.professional_schedules DROP COLUMN professional_id;
ALTER TABLE public.professional_schedules RENAME COLUMN new_prof_id TO professional_id;

ALTER TABLE public.professional_schedules 
ADD CONSTRAINT professional_schedules_professional_id_fkey 
FOREIGN KEY (professional_id) REFERENCES public.professionals(id) ON DELETE CASCADE;

-- 4. APPLY CHECK CONSTRAINT (Now safe)
ALTER TABLE public.users DROP CONSTRAINT IF EXISTS check_professional_role_link;
ALTER TABLE public.users ADD CONSTRAINT check_professional_role_link CHECK (
  (role = 'DENTIST' AND professional_id IS NOT NULL) OR
  (role = 'ADMIN') OR 
  (role IN ('RECEPTIONIST', 'ASSISTANT') AND professional_id IS NULL)
);

-- 5. CREATE TRANSACTIONAL RPC (Same as before)
CREATE OR REPLACE FUNCTION public.manage_user_professional(
    p_user_id UUID, 
    p_clinic_id UUID,
    p_name TEXT,
    p_email TEXT,
    p_role role,
    p_color TEXT,
    p_active BOOLEAN,
    p_professional_data JSONB 
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_user_id UUID;
    v_prof_id UUID;
BEGIN
    IF p_user_id IS NULL THEN
        v_user_id := uuid_generate_v4(); 
    ELSE
        v_user_id := p_user_id;
    END IF;

    IF (p_role = 'DENTIST') OR (p_role = 'ADMIN' AND p_professional_data IS NOT NULL) THEN
        SELECT professional_id INTO v_prof_id FROM public.users WHERE id = v_user_id;
        
        IF v_prof_id IS NOT NULL THEN
            UPDATE public.professionals
            SET 
                name = p_name, 
                crc = p_professional_data->>'council_number',
                council = p_professional_data->>'council_type',
                specialty = p_professional_data->>'specialty',
                color = p_color,
                is_active = p_active
            WHERE id = v_prof_id;
        ELSE
            INSERT INTO public.professionals (
                clinic_id, name, crc, council, specialty, color, is_active
            ) VALUES (
                p_clinic_id,
                p_name,
                p_professional_data->>'council_number',
                p_professional_data->>'council_type',
                p_professional_data->>'specialty',
                p_color,
                p_active
            ) RETURNING id INTO v_prof_id;
        END IF;

    ELSE
        v_prof_id := NULL;
    END IF;

    INSERT INTO public.users (
        id, clinic_id, email, name, role, color, active, professional_id
    ) VALUES (
        v_user_id, p_clinic_id, p_email, p_name, p_role, p_color, p_active, v_prof_id
    )
    ON CONFLICT (id) DO UPDATE SET
        name = EXCLUDED.name,
        email = EXCLUDED.email,
        role = EXCLUDED.role,
        color = EXCLUDED.color,
        active = EXCLUDED.active,
        professional_id = v_prof_id;

    RETURN jsonb_build_object('user_id', v_user_id, 'professional_id', v_prof_id);
END;
$$;
