-- Verificando se as novas tabelas de preço (tipo CONVENIO) têm itens vinculados
SELECT 
    pt.name, 
    pt.type, 
    pt.id,
    (SELECT count(*) FROM public.price_table_items pti WHERE pti.price_table_id = pt.id) as items_count
FROM public.price_tables pt
WHERE pt.type = 'CONVENIO';

-- Verificando tabelas antigas referenciadas por Conventions
SELECT 
    c.name as convention_name, 
    c.price_table_id,
    pt.name as linked_table_name,
    (SELECT count(*) FROM public.price_table_items pti WHERE pti.price_table_id = c.price_table_id) as items_in_linked
FROM public.conventions c
LEFT JOIN public.price_tables pt ON c.price_table_id = pt.id;
